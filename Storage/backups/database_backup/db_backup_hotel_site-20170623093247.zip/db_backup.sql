#
# TABLE STRUCTURE FOR: company
#

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `street_address` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(20) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `other_phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(100) NOT NULL,
  `company_type` varchar(50) NOT NULL,
  `company_grade` varchar(50) NOT NULL,
  `reg_no` varchar(50) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(11) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', 'Kurier it', 'Galle Road', '', 'Dehiwela', 'Western Province', 'LK', '12090', '0775440889', '0775440889', '0775440889', 'fahrydgt@gmail.com', 'www.zoneventure.com', 'Online ', '5 star', 'REG001-A', 'logo_1.png', '1', '2016-04-27', '1', '2017-06-23', '1', '0', '0000-00-00', '0');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('2', 'Zone Venture Software Solution', '9/4, Dharga Lane, Dharga Town', '', 'Dharga Town', 'Western', 'LK', '12090', '0775440889', '0775440889', '0775440889', 'fahrydgt@gmail.com', 'www.zoneventure.com', 'Software', '3', '', 'logo.jpg', '1', '2017-06-19', '1', '2017-06-19', '1', '1', '2017-06-19', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('3', 'Zone Venture Software Solution', '9/4,Dharga Lane,, ', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '0775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-21', '1', '0000-00-00', '0', '1', '2017-06-21', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('4', 'Zone Venture Software Solution1', '9/4,Dharga Lane,', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '00775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('5', 'Zone Venture Software Solution1', '9/4,Dharga Lane,', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '00775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('6', 'Zone Venture Software Solution1', '9/4,Dharga Lane,', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '00775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('11', 'Zone Venture Software Solution1', '9/4,Dharga Lane,', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '00775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('12', 'Zone Venture Software Solution1', '9/4,Dharga Lane,', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '00775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('13', 'Zone Venture Software Solution', '9/4,Dharga Lane,, ', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '0775440889', '000775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');
INSERT INTO `company` (`id`, `company_name`, `street_address`, `address2`, `city`, `state`, `country`, `zipcode`, `phone`, `fax`, `other_phone`, `email`, `website`, `company_type`, `company_grade`, `reg_no`, `logo`, `status`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('14', 'Zone Venture Software Solution11', '9/4,Dharga Lane,, ', '', 'Dharga Town.', '', 'LK', '12090', '0775440889', '', '0775440889', 'fahrydgt@gmail.com', '', 'Software', '', '', 'logo.jpg', '1', '2017-06-23', '1', '0000-00-00', '0', '1', '2017-06-23', '1');


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  `lat` varchar(50) NOT NULL,
  `lng` varchar(50) NOT NULL,
  `deleted` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_code` (`country_code`)
) ENGINE=MyISAM AUTO_INCREMENT=248 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('1', 'US', 'United States', '38', '-97', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('2', 'CA', 'Canada', '60', '-95', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('3', 'AF', 'Afghanistan', '33', '65', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('4', 'AL', 'Albania', '41', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('5', 'DZ', 'Algeria', '28', '3', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('6', 'DS', 'American Samoa', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('7', 'AD', 'Andorra', '42.5', '1.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('8', 'AO', 'Angola', '-12.5', '18.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('9', 'AI', 'Anguilla', '18.25', '-63.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('10', 'AQ', 'Antarctica', '-90', '0', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('11', 'AG', 'Antigua and/or Barbuda', '17.05', '-61.8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('12', 'AR', 'Argentina', '-34', '-64', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('13', 'AM', 'Armenia', '40', '45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('14', 'AW', 'Aruba', '12.5', '-69.96666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('15', 'AU', 'Australia', '-27', '133', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('16', 'AT', 'Austria', '47.33333333', '13.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('17', 'AZ', 'Azerbaijan', '40.5', '47.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('18', 'BS', 'Bahamas', '24.25', '-76', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('19', 'BH', 'Bahrain', '26', '50.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('20', 'BD', 'Bangladesh', '24', '90', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('21', 'BB', 'Barbados', '13.16666666', '-59.53333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('22', 'BY', 'Belarus', '53', '28', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('23', 'BE', 'Belgium', '50.83333333', '4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('24', 'BZ', 'Belize', '17.25', '-88.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('25', 'BJ', 'Benin', '9.5', '2.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('26', 'BM', 'Bermuda', '32.33333333', '-64.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('27', 'BT', 'Bhutan', '27.5', '90.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('28', 'BO', 'Bolivia', '-17', '-65', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('29', 'BA', 'Bosnia and Herzegovina', '44', '18', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('30', 'BW', 'Botswana', '-22', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('31', 'BV', 'Bouvet Island', '-54.43333333', '3.4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('32', 'BR', 'Brazil', '-10', '-55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('33', 'IO', 'British Indian Ocean Territory', '-6', '71.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('34', 'BN', 'Brunei Darussalam', '4.5', '114.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('35', 'BG', 'Bulgaria', '43', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('36', 'BF', 'Burkina Faso', '13', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('37', 'BI', 'Burundi', '-3.5', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('38', 'KH', 'Cambodia', '13', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('39', 'CM', 'Cameroon', '6', '12', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('40', 'CV', 'Cape Verde', '16', '-24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('41', 'KY', 'Cayman Islands', '19.5', '-80.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('42', 'CF', 'Central African Republic', '7', '21', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('43', 'TD', 'Chad', '15', '19', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('44', 'CL', 'Chile', '-30', '-71', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('45', 'CN', 'China', '35', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('46', 'CX', 'Christmas Island', '-10.5', '105.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('47', 'CC', 'Cocos (Keeling) Islands', '-12.5', '96.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('48', 'CO', 'Colombia', '4', '-72', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('49', 'KM', 'Comoros', '-12.16666666', '44.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('50', 'CG', 'Congo', '-1', '15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('51', 'CK', 'Cook Islands', '-21.23333333', '-159.76666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('52', 'CR', 'Costa Rica', '10', '-84', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('53', 'HR', 'Croatia (Hrvatska)', '45.16666666', '15.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('54', 'CU', 'Cuba', '21.5', '-80', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('55', 'CY', 'Cyprus', '35', '33', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('56', 'CZ', 'Czech Republic', '49.75', '15.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('57', 'DK', 'Denmark', '56', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('58', 'DJ', 'Djibouti', '11.5', '43', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('59', 'DM', 'Dominica', '15.41666666', '-61.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('60', 'DO', 'Dominican Republic', '19', '-70.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('61', 'TP', 'East Timor', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('62', 'EC', 'Ecuador', '-2', '-77.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('63', 'EG', 'Egypt', '27', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('64', 'SV', 'El Salvador', '13.83333333', '-88.91666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('65', 'GQ', 'Equatorial Guinea', '2', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('66', 'ER', 'Eritrea', '15', '39', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('67', 'EE', 'Estonia', '59', '26', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('68', 'ET', 'Ethiopia', '8', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('69', 'FK', 'Falkland Islands (Malvinas)', '-51.75', '-59', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('70', 'FO', 'Faroe Islands', '62', '-7', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('71', 'FJ', 'Fiji', '-18', '175', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('72', 'FI', 'Finland', '64', '26', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('73', 'FR', 'France', '46', '2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('74', 'FX', 'France, Metropolitan', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('75', 'GF', 'French Guiana', '4', '-53', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('76', 'PF', 'French Polynesia', '-15', '-140', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('77', 'TF', 'French Southern Territories', '-49.25', '69.167', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('78', 'GA', 'Gabon', '-1', '11.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('79', 'GM', 'Gambia', '13.46666666', '-16.56666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('80', 'GE', 'Georgia', '42', '43.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('81', 'DE', 'Germany', '51', '9', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('82', 'GH', 'Ghana', '8', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('83', 'GI', 'Gibraltar', '36.13333333', '-5.35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('246', 'GK', 'Guernsey', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('84', 'GR', 'Greece', '39', '22', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('85', 'GL', 'Greenland', '72', '-40', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('86', 'GD', 'Grenada', '12.11666666', '-61.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('87', 'GP', 'Guadeloupe', '16.25', '-61.583333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('88', 'GU', 'Guam', '13.46666666', '144.78333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('89', 'GT', 'Guatemala', '15.5', '-90.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('90', 'GN', 'Guinea', '11', '-10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('91', 'GW', 'Guinea-Bissau', '12', '-15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('92', 'GY', 'Guyana', '5', '-59', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('93', 'HT', 'Haiti', '19', '-72.41666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('94', 'HM', 'Heard and Mc Donald Islands', '-53.1', '72.51666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('95', 'HN', 'Honduras', '15', '-86.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('96', 'HK', 'Hong Kong', '22.267', '114.188', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('97', 'HU', 'Hungary', '47', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('98', 'IS', 'Iceland', '65', '-18', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('99', 'IN', 'India', '20', '77', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('244', 'IM', 'Isle of Man', '54.25', '-4.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('100', 'ID', 'Indonesia', '-5', '120', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('101', 'IR', 'Iran (Islamic Republic of)', '32', '53', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('102', 'IQ', 'Iraq', '33', '44', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('103', 'IE', 'Ireland', '53', '-8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('104', 'IL', 'Israel', '31.47', '35.13', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('105', 'IT', 'Italy', '42.83333333', '12.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('106', 'CI', 'Ivory Coast', '8', '-5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('245', 'JE', 'Jersey', '49.25', '-2.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('107', 'JM', 'Jamaica', '18.25', '-77.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('108', 'JP', 'Japan', '36', '138', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('109', 'JO', 'Jordan', '31', '36', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('110', 'KZ', 'Kazakhstan', '48', '68', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('111', 'KE', 'Kenya', '1', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('112', 'KI', 'Kiribati', '1.41666666', '173', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('113', 'KP', 'Korea, Democratic People\'s Republic of', '40', '127', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('114', 'KR', 'Korea, Republic of', '37', '127.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('115', 'XK', 'Kosovo', '42.666667', '21.166667', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('116', 'KW', 'Kuwait', '29.5', '45.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('117', 'KG', 'Kyrgyzstan', '41', '75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('118', 'LA', 'Lao People\'s Democratic Republic', '18', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('119', 'LV', 'Latvia', '57', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('120', 'LB', 'Lebanon', '33.83333333', '35.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('121', 'LS', 'Lesotho', '-29.5', '28.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('122', 'LR', 'Liberia', '6.5', '-9.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('123', 'LY', 'Libyan Arab Jamahiriya', '25', '17', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('124', 'LI', 'Liechtenstein', '47.26666666', '9.53333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('125', 'LT', 'Lithuania', '56', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('126', 'LU', 'Luxembourg', '49.75', '6.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('127', 'MO', 'Macau', '22.16666666', '113.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('128', 'MK', 'Macedonia', '41.83333333', '22', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('129', 'MG', 'Madagascar', '-20', '47', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('130', 'MW', 'Malawi', '-13.5', '34', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('131', 'MY', 'Malaysia', '2.5', '112.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('132', 'MV', 'Maldives', '3.25', '73', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('133', 'ML', 'Mali', '17', '-4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('134', 'MT', 'Malta', '35.83333333', '14.58333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('135', 'MH', 'Marshall Islands', '9', '168', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('136', 'MQ', 'Martinique', '14.666667', '-61', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('137', 'MR', 'Mauritania', '20', '-12', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('138', 'MU', 'Mauritius', '-20.28333333', '57.55', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('139', 'TY', 'Mayotte', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('140', 'MX', 'Mexico', '23', '-102', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('141', 'FM', 'Micronesia, Federated States of', '6.91666666', '158.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('142', 'MD', 'Moldova, Republic of', '47', '29', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('143', 'MC', 'Monaco', '43.73333333', '7.4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('144', 'MN', 'Mongolia', '46', '105', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('145', 'ME', 'Montenegro', '42.5', '19.3', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('146', 'MS', 'Montserrat', '16.75', '-62.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('147', 'MA', 'Morocco', '32', '-5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('148', 'MZ', 'Mozambique', '-18.25', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('149', 'MM', 'Myanmar', '22', '98', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('150', 'NA', 'Namibia', '-22', '17', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('151', 'NR', 'Nauru', '-0.53333333', '166.91666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('152', 'NP', 'Nepal', '28', '84', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('153', 'NL', 'Netherlands', '52.5', '5.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('154', 'AN', 'Netherlands Antilles', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('155', 'NC', 'New Caledonia', '-21.5', '165.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('156', 'NZ', 'New Zealand', '-41', '174', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('157', 'NI', 'Nicaragua', '13', '-85', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('158', 'NE', 'Niger', '16', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('159', 'NG', 'Nigeria', '10', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('160', 'NU', 'Niue', '-19.03333333', '-169.86666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('161', 'NF', 'Norfolk Island', '-29.03333333', '167.95', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('162', 'MP', 'Northern Mariana Islands', '15.2', '145.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('163', 'NO', 'Norway', '62', '10', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('164', 'OM', 'Oman', '21', '57', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('165', 'PK', 'Pakistan', '30', '70', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('166', 'PW', 'Palau', '7.5', '134.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('243', 'PS', 'Palestine', '31.9', '35.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('167', 'PA', 'Panama', '9', '-80', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('168', 'PG', 'Papua New Guinea', '-6', '147', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('169', 'PY', 'Paraguay', '-23', '-58', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('170', 'PE', 'Peru', '-10', '-76', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('171', 'PH', 'Philippines', '13', '122', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('172', 'PN', 'Pitcairn', '-25.06666666', '-130.1', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('173', 'PL', 'Poland', '52', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('174', 'PT', 'Portugal', '39.5', '-8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('175', 'PR', 'Puerto Rico', '18.25', '-66.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('176', 'QA', 'Qatar', '25.5', '51.25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('177', 'RE', 'Reunion', '-21.15', '55.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('178', 'RO', 'Romania', '46', '25', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('179', 'RU', 'Russian Federation', '60', '100', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('180', 'RW', 'Rwanda', '-2', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('181', 'KN', 'Saint Kitts and Nevis', '17.33333333', '-62.75', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('182', 'LC', 'Saint Lucia', '13.88333333', '-60.96666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('183', 'VC', 'Saint Vincent and the Grenadines', '13.25', '-61.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('184', 'WS', 'Samoa', '-13.58333333', '-172.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('185', 'SM', 'San Marino', '43.76666666', '12.41666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('186', 'ST', 'Sao Tome and Principe', '1', '7', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('187', 'SA', 'Saudi Arabia', '25', '45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('188', 'SN', 'Senegal', '14', '-14', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('189', 'RS', 'Serbia', '44', '21', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('190', 'SC', 'Seychelles', '-4.58333333', '55.66666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('191', 'SL', 'Sierra Leone', '8.5', '-11.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('192', 'SG', 'Singapore', '1.36666666', '103.8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('193', 'SK', 'Slovakia', '48.66666666', '19.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('194', 'SI', 'Slovenia', '46.11666666', '14.81666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('195', 'SB', 'Solomon Islands', '-8', '159', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('196', 'SO', 'Somalia', '10', '49', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('197', 'ZA', 'South Africa', '-29', '24', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('198', 'GS', 'South Georgia South Sandwich Islands', '-54.5', '-37', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('199', 'ES', 'Spain', '40', '-4', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('200', 'LK', 'Sri Lanka', '7', '81', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('201', 'SH', 'St. Helena', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('202', 'PM', 'St. Pierre and Miquelon', '46.83333333', '-56.33333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('203', 'SD', 'Sudan', '15', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('204', 'SR', 'Suriname', '4', '-56', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('205', 'SJ', 'Svalbard and Jan Mayen Islands', '78', '20', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('206', 'SZ', 'Swaziland', '-26.5', '31.5', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('207', 'SE', 'Sweden', '62', '15', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('208', 'CH', 'Switzerland', '47', '8', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('209', 'SY', 'Syrian Arab Republic', '35', '38', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('210', 'TW', 'Taiwan', '23.5', '121', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('211', 'TJ', 'Tajikistan', '39', '71', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('212', 'TZ', 'Tanzania, United Republic of', '-6', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('213', 'TH', 'Thailand', '15', '100', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('214', 'TG', 'Togo', '8', '1.16666666', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('215', 'TK', 'Tokelau', '-9', '-172', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('216', 'TO', 'Tonga', '-20', '-175', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('217', 'TT', 'Trinidad and Tobago', '11', '-61', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('218', 'TN', 'Tunisia', '34', '9', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('219', 'TR', 'Turkey', '39', '35', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('220', 'TM', 'Turkmenistan', '40', '60', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('221', 'TC', 'Turks and Caicos Islands', '21.75', '-71.58333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('222', 'TV', 'Tuvalu', '-8', '178', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('223', 'UG', 'Uganda', '1', '32', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('224', 'UA', 'Ukraine', '49', '32', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('225', 'AE', 'United Arab Emirates', '24', '54', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('226', 'GB', 'United Kingdom', '54', '-2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('227', 'UM', 'United States minor outlying islands', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('228', 'UY', 'Uruguay', '-33', '-56', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('229', 'UZ', 'Uzbekistan', '41', '64', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('230', 'VU', 'Vanuatu', '-16', '167', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('231', 'VA', 'Vatican City State', '41.9', '12.45', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('232', 'VE', 'Venezuela', '8', '-66', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('233', 'VN', 'Vietnam', '16.16666666', '107.83333333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('234', 'VG', 'Virgin Islands (British)', '18.431383', '-64.62305', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('235', 'VI', 'Virgin Islands (U.S.)', '18.35', '-64.933333', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('236', 'WF', 'Wallis and Futuna Islands', '-13.3', '-176.2', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('237', 'EH', 'Western Sahara', '24.5', '-13', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('238', 'YE', 'Yemen', '15', '48', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('239', 'YU', 'Yugoslavia', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('240', 'ZR', 'Zaire', '', '', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('241', 'ZM', 'Zambia', '-15', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('242', 'ZW', 'Zimbabwe', '-20', '30', '0');
INSERT INTO `countries` (`id`, `country_code`, `country_name`, `lat`, `lng`, `deleted`) VALUES ('247', '--', 'Not Specified', '0', '-0', '0');


#
# TABLE STRUCTURE FOR: module_actions
#

DROP TABLE IF EXISTS `module_actions`;

CREATE TABLE `module_actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('1', '1', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('2', '4', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('3', '3', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('4', '6', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('20', '6', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('6', '5', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('7', '5', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('8', '5', 'Validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('9', '5', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('10', '5', 'Search', 'search_company', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('11', '5', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('12', '5', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('13', '2', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('14', '2', 'Add', 'add', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('15', '2', 'Validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('16', '2', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('17', '2', 'Search', 'search_user', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('18', '2', 'View', 'view', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('19', '2', 'Delete', 'delete', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('21', '6', 'Edit', 'edit', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('22', '6', 'Validate', 'validate', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('23', '5', 'Test', 'test', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('24', '7', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('25', '7', 'Backup Database', 'backup_db', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('26', '8', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('27', '9', 'index', 'index', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('28', '9', 'Search System Log', 'search_audit_trials', '1');
INSERT INTO `module_actions` (`id`, `module_id`, `name`, `action`, `status`) VALUES ('29', '9', 'View', 'view', '1');


#
# TABLE STRUCTURE FOR: module_user_role
#

DROP TABLE IF EXISTS `module_user_role`;

CREATE TABLE `module_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(10) NOT NULL,
  `module_action_id` int(10) NOT NULL,
  `display_order` int(10) NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('1', '1', '1', '101', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('2', '1', '2', '401', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('3', '1', '3', '301', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('4', '1', '4', '303', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('23', '1', '23', '601', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('6', '1', '6', '303', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('7', '1', '7', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('8', '1', '8', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('9', '1', '9', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('10', '1', '10', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('11', '1', '11', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('12', '1', '12', '502', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('13', '1', '13', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('14', '1', '14', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('15', '1', '15', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('16', '1', '16', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('17', '1', '17', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('18', '1', '18', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('19', '1', '19', '202', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('20', '1', '20', '601', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('21', '1', '21', '601', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('22', '1', '22', '601', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('24', '1', '24', '701', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('25', '1', '25', '702', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('26', '1', '26', '702', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('27', '1', '27', '702', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('28', '1', '28', '702', '1');
INSERT INTO `module_user_role` (`id`, `user_role_id`, `module_action_id`, `display_order`, `status`) VALUES ('29', '1', '29', '702', '1');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) NOT NULL,
  `page_id` varchar(200) NOT NULL,
  `img_class` varchar(50) NOT NULL,
  `is_parent` int(5) NOT NULL COMMENT '1-first_level, 2- second_level',
  `show_below` int(5) NOT NULL,
  `hidden` int(5) NOT NULL,
  `user_permission_apply` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('1', 'Dashboard', 'dashboard', 'fa fa-dashboard', '1', '0', '0', '0');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('2', 'Users', 'users', 'fa fa-user', '2', '3', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('3', 'All Users', '#', 'fa fa-user', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('4', 'Settings', '#', 'fa fa-gears', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('5', 'Company Details', 'company', 'fa fa-building-o', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('6', 'User Permission', 'userPermission', 'fa fa-lock', '0', '3', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('7', 'Backup', 'backup', 'fa fa-hdd-o', '0', '4', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('8', 'Reports', '#', 'fa fa-bar-chart', '1', '0', '0', '1');
INSERT INTO `modules` (`id`, `module_name`, `page_id`, `img_class`, `is_parent`, `show_below`, `hidden`, `user_permission_apply`) VALUES ('9', 'Audit Trials', 'AuditTrials', 'fa fa-history', '0', '8', '0', '1');


#
# TABLE STRUCTURE FOR: system_log
#

DROP TABLE IF EXISTS `system_log`;

CREATE TABLE `system_log` (
  `id` int(11) NOT NULL,
  `user_id` int(10) NOT NULL,
  `module_id` varchar(50) NOT NULL,
  `action_id` varchar(50) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `system_log` (`id`, `user_id`, `module_id`, `action_id`, `ip`, `date`) VALUES ('1', '1', 'backup', 'backup_db', '::1', '1498189084');
INSERT INTO `system_log` (`id`, `user_id`, `module_id`, `action_id`, `ip`, `date`) VALUES ('2', '1', 'company', 'remove', '::1', '1498189412');
INSERT INTO `system_log` (`id`, `user_id`, `module_id`, `action_id`, `ip`, `date`) VALUES ('3', '1', 'company', 'update', '::1', '1498189465');
INSERT INTO `system_log` (`id`, `user_id`, `module_id`, `action_id`, `ip`, `date`) VALUES ('4', '1', 'company', 'update', '::1', '1498189465');
INSERT INTO `system_log` (`id`, `user_id`, `module_id`, `action_id`, `ip`, `date`) VALUES ('5', '1', 'users', 'update', '::1', '1498189528');


#
# TABLE STRUCTURE FOR: system_log_detail
#

DROP TABLE IF EXISTS `system_log_detail`;

CREATE TABLE `system_log_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system_log_id` int(15) NOT NULL,
  `table_name` varchar(50) NOT NULL,
  `data_new` text NOT NULL,
  `data_old` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `system_log_detail` (`id`, `system_log_id`, `table_name`, `data_new`, `data_old`) VALUES ('1', '1', '', 'N;', 's:0:\"\";');
INSERT INTO `system_log_detail` (`id`, `system_log_id`, `table_name`, `data_new`, `data_old`) VALUES ('2', '2', 'company', 's:0:\"\";', 'a:1:{i:0;a:25:{s:2:\"id\";s:2:\"14\";s:12:\"company_name\";s:32:\"Zone Venture Software Solution11\";s:14:\"street_address\";s:18:\"9/4,Dharga Lane,, \";s:8:\"address2\";s:0:\"\";s:4:\"city\";s:12:\"Dharga Town.\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"LK\";s:7:\"zipcode\";s:5:\"12090\";s:5:\"phone\";s:10:\"0775440889\";s:3:\"fax\";s:0:\"\";s:11:\"other_phone\";s:10:\"0775440889\";s:5:\"email\";s:18:\"fahrydgt@gmail.com\";s:7:\"website\";s:0:\"\";s:12:\"company_type\";s:8:\"Software\";s:13:\"company_grade\";s:0:\"\";s:6:\"reg_no\";s:0:\"\";s:4:\"logo\";s:8:\"logo.jpg\";s:6:\"status\";s:1:\"1\";s:8:\"added_on\";s:10:\"2017-06-23\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"0000-00-00\";s:10:\"updated_by\";s:1:\"0\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";}}');
INSERT INTO `system_log_detail` (`id`, `system_log_id`, `table_name`, `data_new`, `data_old`) VALUES ('3', '3', 'company', 'a:1:{i:0;a:25:{s:2:\"id\";s:1:\"1\";s:12:\"company_name\";s:9:\"Kurier it\";s:14:\"street_address\";s:17:\"9/4,Dharga Lane,,\";s:8:\"address2\";s:0:\"\";s:4:\"city\";s:12:\"Dharga Town.\";s:5:\"state\";s:17:\"Western Province2\";s:7:\"country\";s:2:\"LK\";s:7:\"zipcode\";s:5:\"12090\";s:5:\"phone\";s:10:\"0775440889\";s:3:\"fax\";s:10:\"0775440889\";s:11:\"other_phone\";s:10:\"0775440889\";s:5:\"email\";s:18:\"fahrydgt@gmail.com\";s:7:\"website\";s:19:\"www.zoneventure.com\";s:12:\"company_type\";s:7:\"Online \";s:13:\"company_grade\";s:6:\"5 star\";s:6:\"reg_no\";s:8:\"REG001-A\";s:4:\"logo\";s:10:\"logo_1.png\";s:6:\"status\";s:1:\"1\";s:8:\"added_on\";s:10:\"2016-04-27\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-21\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";}}', 'a:1:{i:0;a:25:{s:2:\"id\";s:1:\"1\";s:12:\"company_name\";s:9:\"Kurier it\";s:14:\"street_address\";s:10:\"Galle Road\";s:8:\"address2\";s:0:\"\";s:4:\"city\";s:8:\"Dehiwela\";s:5:\"state\";s:16:\"Western Province\";s:7:\"country\";s:2:\"LK\";s:7:\"zipcode\";s:5:\"12090\";s:5:\"phone\";s:10:\"0775440889\";s:3:\"fax\";s:10:\"0775440889\";s:11:\"other_phone\";s:10:\"0775440889\";s:5:\"email\";s:18:\"fahrydgt@gmail.com\";s:7:\"website\";s:19:\"www.zoneventure.com\";s:12:\"company_type\";s:7:\"Online \";s:13:\"company_grade\";s:6:\"5 star\";s:6:\"reg_no\";s:8:\"REG001-A\";s:4:\"logo\";s:10:\"logo_1.png\";s:6:\"status\";s:1:\"1\";s:8:\"added_on\";s:10:\"2016-04-27\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-23\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";}}');
INSERT INTO `system_log_detail` (`id`, `system_log_id`, `table_name`, `data_new`, `data_old`) VALUES ('4', '4', 'company', 'a:1:{i:0;a:25:{s:2:\"id\";s:1:\"1\";s:12:\"company_name\";s:9:\"Kurier it\";s:14:\"street_address\";s:10:\"Galle Road\";s:8:\"address2\";s:0:\"\";s:4:\"city\";s:8:\"Dehiwela\";s:5:\"state\";s:16:\"Western Province\";s:7:\"country\";s:2:\"LK\";s:7:\"zipcode\";s:5:\"12090\";s:5:\"phone\";s:10:\"0775440889\";s:3:\"fax\";s:10:\"0775440889\";s:11:\"other_phone\";s:10:\"0775440889\";s:5:\"email\";s:18:\"fahrydgt@gmail.com\";s:7:\"website\";s:19:\"www.zoneventure.com\";s:12:\"company_type\";s:7:\"Online \";s:13:\"company_grade\";s:6:\"5 star\";s:6:\"reg_no\";s:8:\"REG001-A\";s:4:\"logo\";s:10:\"logo_1.png\";s:6:\"status\";s:1:\"1\";s:8:\"added_on\";s:10:\"2016-04-27\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-23\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";}}', 'a:1:{i:0;a:25:{s:2:\"id\";s:1:\"1\";s:12:\"company_name\";s:9:\"Kurier it\";s:14:\"street_address\";s:10:\"Galle Road\";s:8:\"address2\";s:0:\"\";s:4:\"city\";s:8:\"Dehiwela\";s:5:\"state\";s:16:\"Western Province\";s:7:\"country\";s:2:\"LK\";s:7:\"zipcode\";s:5:\"12090\";s:5:\"phone\";s:10:\"0775440889\";s:3:\"fax\";s:10:\"0775440889\";s:11:\"other_phone\";s:10:\"0775440889\";s:5:\"email\";s:18:\"fahrydgt@gmail.com\";s:7:\"website\";s:19:\"www.zoneventure.com\";s:12:\"company_type\";s:7:\"Online \";s:13:\"company_grade\";s:6:\"5 star\";s:6:\"reg_no\";s:8:\"REG001-A\";s:4:\"logo\";s:10:\"logo_1.png\";s:6:\"status\";s:1:\"1\";s:8:\"added_on\";s:10:\"2016-04-27\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-23\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";}}');
INSERT INTO `system_log_detail` (`id`, `system_log_id`, `table_name`, `data_new`, `data_old`) VALUES ('5', '5', 'user_auth-user_details', 'a:1:{i:0;a:20:{s:2:\"id\";s:2:\"15\";s:7:\"auth_id\";s:2:\"16\";s:10:\"first_name\";s:7:\"Shafras\";s:9:\"last_name\";s:5:\"Nawas\";s:10:\"company_id\";s:1:\"1\";s:7:\"address\";s:0:\"\";s:5:\"email\";s:20:\"shafrasnawas@aol.com\";s:3:\"tel\";s:10:\"0112121212\";s:3:\"pic\";s:11:\"default.jpg\";s:8:\"added_on\";s:10:\"2016-04-25\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-23\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";s:9:\"user_name\";s:7:\"shafras\";s:6:\"status\";s:1:\"1\";s:9:\"user_role\";s:20:\"System Administrator\";s:12:\"user_role_id\";s:1:\"2\";}}', 'a:1:{i:0;a:20:{s:2:\"id\";s:2:\"15\";s:7:\"auth_id\";s:2:\"16\";s:10:\"first_name\";s:7:\"Shafras\";s:9:\"last_name\";s:5:\"Nawas\";s:10:\"company_id\";s:1:\"1\";s:7:\"address\";s:0:\"\";s:5:\"email\";s:20:\"shafrasnawas@aol.com\";s:3:\"tel\";s:10:\"0112121212\";s:3:\"pic\";s:11:\"default.jpg\";s:8:\"added_on\";s:10:\"2016-04-25\";s:8:\"added_by\";s:1:\"1\";s:10:\"updated_on\";s:10:\"2017-06-23\";s:10:\"updated_by\";s:1:\"1\";s:7:\"deleted\";s:1:\"0\";s:10:\"deleted_on\";s:10:\"0000-00-00\";s:10:\"deleted_by\";s:1:\"0\";s:9:\"user_name\";s:7:\"shafras\";s:6:\"status\";s:1:\"1\";s:9:\"user_role\";s:13:\"Administrator\";s:12:\"user_role_id\";s:1:\"1\";}}');


#
# TABLE STRUCTURE FOR: user_auth
#

DROP TABLE IF EXISTS `user_auth`;

CREATE TABLE `user_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_id` int(10) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `user_password` text NOT NULL,
  `tmp_pwd` text NOT NULL,
  `tmp_pwd_req_date` date NOT NULL,
  `active_from` date NOT NULL,
  `active_to` date NOT NULL,
  `status` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_role` (`user_role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('1', '1', 'fahry', 'I98FzpnFLhO2dBhAj0P6pROEu2zqWAq5gcvnvG/aPJrO9m+wNu+ryS9cfBVjDFUVU5S889QriWxf0a+Gw5NkCA==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('16', '2', 'shafras', '7rl87I6HQEFeEykB9s/GfJ3HS+9DYbtBTDm4qEaln9DLu4e8XdDY+pRvvDNMAQZHVIaQInV2oyM7ttHL8rEDGw==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('18', '1', 'faheem', 'nZ/HVzmFhdIQOH06/CjDeRyrNxSMUGsJNy6fcw8+p7YPMllxP4tCJzSLtAyVOVREh1oRhEoLOROiG/bfs4sObA==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('19', '1', 'fahry2', 'kunIBXOpOxX0zARdn6RszBKcKrkC78Jy9DkV/8s7+NOCkl+EiYFFm4z0TzsbIFIX17TsLdRqIkDXb54s/U0G8g==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('20', '1', 'fahry3', 'F174Q1SVFGMPbuOdGRFUlpWNCR3oLuQ+GxYXO6hFSg8nboeZ68GsdtsF3PXvBUqZNb1GLAo+unWXqG7pAtyVjg==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');
INSERT INTO `user_auth` (`id`, `user_role_id`, `user_name`, `user_password`, `tmp_pwd`, `tmp_pwd_req_date`, `active_from`, `active_to`, `status`) VALUES ('21', '1', 'fahry4', 's0C8EY0pceIxk1DLIJiSgVTAZDmefXj6FhCFRyLAKI+MJfsWvmozdmgdmpZ8f+4SLyQ/NHe8uQuqZKGkeWf8EA==', '', '0000-00-00', '0000-00-00', '0000-00-00', '1');


#
# TABLE STRUCTURE FOR: user_details
#

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_id` int(10) NOT NULL,
  `first_name` varchar(75) NOT NULL,
  `last_name` varchar(75) NOT NULL,
  `company_id` int(10) NOT NULL DEFAULT '1',
  `address` varchar(150) NOT NULL,
  `email` varchar(75) NOT NULL,
  `tel` varchar(15) NOT NULL,
  `pic` text NOT NULL,
  `added_on` date NOT NULL,
  `added_by` int(5) NOT NULL,
  `updated_on` date NOT NULL,
  `updated_by` int(5) NOT NULL,
  `deleted` int(5) NOT NULL,
  `deleted_on` date NOT NULL,
  `deleted_by` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_auth` (`auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('1', '1', 'Fahry', 'Lafir', '1', '82, W. A. D. Ramanayake Mawatha, Colombo - 02', 'fahrydgt@gmail.com', '0775440889', 'default.jpg', '2016-01-13', '1', '2017-06-23', '1', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('15', '16', 'Shafras', 'Nawas', '1', '', 'shafrasnawas@aol.com', '0112121212', 'default.jpg', '2016-04-25', '1', '2017-06-23', '1', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('17', '18', 'Faheem', 'Farook', '1', '', 'faheem@gmai.com', '+94775440889', 'default.png', '2017-06-19', '1', '2017-06-23', '18', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('18', '19', 'Fahry2', 'lafir2', '1', '', 'fahrydgt@gmail.com', '+94775440889', '', '2017-06-19', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('19', '20', 'Fahry3', 'lafir3', '1', '', 'fahrydgt@gmail.com', '+94775440889', '', '2017-06-19', '1', '0000-00-00', '0', '0', '0000-00-00', '0');
INSERT INTO `user_details` (`id`, `auth_id`, `first_name`, `last_name`, `company_id`, `address`, `email`, `tel`, `pic`, `added_on`, `added_by`, `updated_on`, `updated_by`, `deleted`, `deleted_on`, `deleted_by`) VALUES ('20', '21', 'Fahry', 'lafir2', '1', '', 'fahrydgt@gmail.com', '+94775440889', 'default.jpg', '2017-06-19', '1', '0000-00-00', '0', '0', '0000-00-00', '0');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(50) NOT NULL,
  `role_cat` varchar(50) NOT NULL,
  `deleted` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_cat` (`role_cat`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('1', 'Administrator', 'ADMIN', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('3', 'Manager', 'MANAGER', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('4', 'Gen Staff', 'STAFF', '0');
INSERT INTO `user_role` (`id`, `user_role`, `role_cat`, `deleted`) VALUES ('2', 'System Administrator', 'SYSTEM_ADMIN', '0');


